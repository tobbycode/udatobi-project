Project 1 info:

Website endpoint URL: http://myproject1bucket-731709748203.s3-website-us-east-1.amazonaws.com

CloudFront domain name URL:d1o22t9bg8xp7c.cloudfront.net
			   